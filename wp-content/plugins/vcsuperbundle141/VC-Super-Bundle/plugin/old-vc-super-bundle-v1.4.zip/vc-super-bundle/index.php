<?php
	// Silence is golden. @codingStandardsIgnoreLine
	// Hide file structure from users on unprotected servers.
