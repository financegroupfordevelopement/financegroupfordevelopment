<?php
/**
 * Uninstallation routine.
 *
 * @version 1.1
 * @package Parallax Backgrounds for VC
 */

// If uninstall is not called from WordPress, exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit();
}
