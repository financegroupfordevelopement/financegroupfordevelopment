<article id="post-<?php the_ID(); ?>">

    <?php the_content(); ?>
    <?php wp_link_pages(); ?>

    <?php //comments_template( '', true );  ?>

</article>