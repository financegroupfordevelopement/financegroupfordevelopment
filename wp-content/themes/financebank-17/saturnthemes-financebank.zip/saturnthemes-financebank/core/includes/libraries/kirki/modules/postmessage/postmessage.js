/**
 * This file is empty on purpose.
 * Scripts are added dynamically using wp_add_inline_script() on this.
 */
