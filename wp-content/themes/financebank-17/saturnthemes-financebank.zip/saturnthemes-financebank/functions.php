<?php

define( 'SaturnThemes_FINANCEBANK_EMAIL', 'saturnthemes@gmail.com' );
define( 'SaturnThemes_FINANCEBANK_THEME_DIR', get_template_directory() . '/' );
define( 'SaturnThemes_FINANCEBANK_THEME_URL', get_template_directory_uri() );
define( 'SaturnThemes_THEME_PREFIX', 'saturnthemes_financebank_' );

require_once( SaturnThemes_FINANCEBANK_THEME_DIR . 'core/core.php' );
require_once( SaturnThemes_FINANCEBANK_THEME_DIR . 'includes/init.php' );
