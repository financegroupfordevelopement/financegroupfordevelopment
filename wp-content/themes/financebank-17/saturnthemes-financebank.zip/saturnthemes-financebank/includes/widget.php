<?php
//Load Widgets
require_once( SaturnThemes_FINANCEBANK_THEME_DIR . 'includes/widget/saturnthemes_social_widget.php' );
require_once( SaturnThemes_FINANCEBANK_THEME_DIR . 'includes/widget/saturnthemes_facebook_widget.php' );
require_once( SaturnThemes_FINANCEBANK_THEME_DIR . 'includes/widget/saturnthemes_instagram_widget.php' );