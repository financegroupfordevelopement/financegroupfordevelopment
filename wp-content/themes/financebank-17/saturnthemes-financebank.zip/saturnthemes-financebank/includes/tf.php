<?php
if ( ! function_exists( 'saturnthemes_bb_en' ) ) {
	function saturnthemes_bb_en( $data ) {
		return '';
	}
}

if ( ! function_exists( 'saturnthemes_bb_de' ) ) {
	function saturnthemes_bb_de( $data ) {
		return '';
	}
}