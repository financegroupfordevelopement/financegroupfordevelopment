<?php
$section  = 'footer_preset';
$priority = 1;